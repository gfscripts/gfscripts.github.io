# gf-ui — Avisos, barra de progreso y texto de ayuda

Interfaz gratuita de **GF Scripts** para FiveM: avisos, barra de progreso y texto de ayuda (`[E] Abrir garaje`) con diseño moderno.

- Funciona en **ESX** y **QBCore**, y también sin framework.
- No necesita compilar nada ni ninguna dependencia.

## Instalación

1. Copia la carpeta `gf-ui` en `resources`.
2. En el `server.cfg`, **antes** de tu framework y del resto de scripts:
   ```
   ensure gf-ui
   ```
3. Cambia el color y las posiciones en `config.lua` si quieres.
4. Prueba con `/gfui_demo`. Cuando esté todo bien, pon `Config.Debug = false`.

## Que ESX use este diseño

En la carpeta `compatibilidad/esx` hay tres recursos que sustituyen a los de ESX:

| Recurso | Qué sustituye |
|---|---|
| `esx_notify` | `ESX.ShowNotification`, `xPlayer.showNotification` |
| `esx_progressbar` | `ESX.Progressbar` |
| `esx_textui` | `ESX.TextUI` y `ESX.HideUI` |

1. Busca en tu servidor las carpetas **`esx_notify`**, **`esx_progressbar`** y **`esx_textui`**. Suelen estar en `resources/[core]`.
2. **Reemplázalas** por las de `compatibilidad/esx`, con el mismo nombre de carpeta.
3. Reinicia el servidor.

A partir de ahí, todos los scripts que usan los avisos, la barra o el texto de ESX salen con el diseño de gf-ui, sin tocar nada más.

## Que QBCore use este diseño

**Barra de progreso:**
1. Busca la carpeta **`progressbar`** de QBCore y **reemplázala** por la de `compatibilidad/qbcore/progressbar`.
2. Asegúrate de que `gf-ui` arranca antes que `progressbar`.

**Avisos:** QBCore los dibuja desde su propio núcleo, así que hay que cambiar una función.
1. Abre `qb-core/client/functions.lua` y busca `function QBCore.Functions.Notify`.
2. Cambia **toda la función** por esta:
   ```lua
   function QBCore.Functions.Notify(text, texttype, length, icon)
       local title, message = nil, text
       if type(text) == 'table' then
           title, message = text.caption, text.text
       end
       exports['gf-ui']:Notify({ type = texttype, title = title, description = message, duration = length })
   end
   ```

**Texto de ayuda (opcional):** en `qb-core/client/drawtext.lua`, cambia las funciones `hideText`, `drawText` y `changeText` por:
```lua
local function hideText()
    exports['gf-ui']:HideText()
end

local function drawText(text, position)
    exports['gf-ui']:ShowText(text, { position = (position == 'right' and 'right') or 'left' })
end

local function changeText(text, position)
    drawText(text, position)
end
```

## Que ox_lib use este diseño (recomendado)

Muchos scripts (garajes, inventario, trabajos...) usan los avisos, barras y textos de **ox_lib**, no los de ESX ni QBCore.
Para que también salgan con este diseño, sigue `compatibilidad/OX_LIB.md`: son unas líneas que se añaden en tres archivos de ox_lib.

## Usarlo en tus scripts

**Cliente**
```lua
-- Aviso: type = 'success' | 'error' | 'inform' | 'warning'
exports['gf-ui']:Notify({ type = 'success', title = 'Garaje', description = 'Vehículo guardado', duration = 5000 })

-- Barra de progreso (devuelve true si termina y false si se cancela)
local ok = exports['gf-ui']:Progress({
    duration = 5000,
    label = 'Reparando el vehículo...',
    canCancel = true,
    disable = { move = true, car = true, combat = true },
    anim = { dict = 'mini@repair', clip = 'fixing_a_ped' },   -- o { scenario = 'WORLD_HUMAN_WELDING' }
    prop = { model = 'prop_tool_spanner01', bone = 57005, pos = vec3(0.1, 0.0, 0.0), rot = vec3(0.0, 0.0, 0.0) },
})

exports['gf-ui']:CancelProgress()
exports['gf-ui']:IsProgressActive()

-- Texto de ayuda
exports['gf-ui']:ShowText('[E] Abrir el garaje')          -- la tecla sale en un cuadrito
exports['gf-ui']:ShowText('Abrir el garaje', { key = 'E', position = 'right' })
exports['gf-ui']:HideText()
exports['gf-ui']:IsTextShown()
```

**Servidor**
```lua
exports['gf-ui']:Notify(source, { type = 'error', description = 'No tienes permiso' })
-- o
TriggerClientEvent('gf-ui:notify', source, { type = 'inform', description = 'Hola' })
```

## Personalizar

En `config.lua` puedes cambiar:
- el color principal;
- la posición de cada cosa: avisos arriba o a un lado, la barra abajo o en el centro, el texto a la izquierda, a la derecha o abajo;
- la duración de los avisos, el sonido, la tecla de cancelar y los textos.

El diseño está en `html/style.css`, en CSS normal: no hace falta compilar.

---

Hecho por **GF Scripts**. Descubre la tablet policial **GF Police** y la radio **GF Radio** en nuestra tienda y en nuestro Discord.
