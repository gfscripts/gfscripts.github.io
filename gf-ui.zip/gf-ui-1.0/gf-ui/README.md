# gf-ui — Notifications, progress bar and help text

Free UI by **GF Scripts** for FiveM: notifications, progress bar and help text (`[E] Open garage`) with a modern design.
Works with **ESX**, **QBCore** or standalone. No build step, no dependencies.

**Install:** drop `gf-ui` in `resources` and add `ensure gf-ui` before your framework. Try `/gfui_demo` (with `Config.Debug = true`).

**ESX:** replace your `esx_notify`, `esx_progressbar` and `esx_textui` folders with the ones in `compatibilidad/esx`.
**QBCore:** replace `progressbar` with `compatibilidad/qbcore/progressbar`, and replace `QBCore.Functions.Notify` in `qb-core/client/functions.lua` with:
```lua
function QBCore.Functions.Notify(text, texttype, length, icon)
    local title, message = nil, text
    if type(text) == 'table' then title, message = text.caption, text.text end
    exports['gf-ui']:Notify({ type = texttype, title = title, description = message, duration = length })
end
```

**Exports (client):** `Notify(data)`, `Progress(data) -> boolean`, `CancelProgress()`, `IsProgressActive()`, `ShowText(text, options)`, `HideText()`, `IsTextShown()`.
**Export (server):** `Notify(source, data)` or event `gf-ui:notify`.

Full guide (Spanish): `LEEME.md`. Texts and colours: `config.lua`.
